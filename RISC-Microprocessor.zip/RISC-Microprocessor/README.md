# RISC-Microprocessor
Designed a 8-register 16-bit multi-cycle processor using RISC architecture based on custom ISA
