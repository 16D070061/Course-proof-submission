def parse(in_string):
	i = 0
	poc = []
	
	temp = []
	while(i<len(in_string)):
		if(in_string[i] == "("):
			temp = []
		elif(in_string[i] == ")"):
			poc.append(temp)
		elif(in_string[i] == "!"):
			temp.append(in_string[i]+in_string[i+1])
			i = i+1
		elif(in_string[i] == "+" or in_string[i] == " "):
			pass
		else:# uncomplimented literal
			temp.append(in_string[i])

		i = i+1
	return poc

def convert(text_in):
        
        var_list = ["n"]
        
        for clause in  text_in:
                for literal in clause:
                        if(not(literal in var_list)):
                                var_list.append(literal)
                        
        var_dict = dict()
        
        for var in var_list:
                if(var[0] == "!"):
                        if(var[1] in var_dict):
                                var_dict[var] = -1*var_dict[var[1]]

                        else:
                                var_dict[var] = -1*(var_list.index(var))
                                var_dict[var[1]] = var_list.index(var)
                else:
                        if("!"+var in var_dict):
                                var_dict[var] = -1*var_dict["!"+var]

                        else:
                                var_dict[var] = var_list.index(var)
                                var_dict["!" + var] = -1*(var_list.index(var))
        #print(var_dict)
        num_out = []
        for clause in text_in:
                temp_clause = []
                for literal in clause:
                        temp_clause.append(var_dict[literal])
                num_out.append(temp_clause)

        return num_out,var_dict


def reconvert(num_in,var_dict):
        text_out = []
        for num in num_in:
                text_out.append(list(var_dict.keys())[list(var_dict.values()).index(num)])

        return text_out

def BCP(poc,value):         
    """BCP returns the simplified version of the input after substituting the value(variable)
    It will return conflict = TRUE if there is unit clause with a different value else returns 
    conflict = FALSE. If clause does not contain value we return it as it is """
    simplified_poc = []
    conflict = False
    for i in range(len(poc)):
        temp_clause = []
        t = 0
        if(len(poc[i])==1):
            if(poc[i][0]==value):
                t = 1
            elif(poc[i][0]== (-1)*value):
                conflict = True
                return([],conflict)
            else:
                temp_clause.append(poc[i][0])
		    
        else:
                
            if(value in poc[i]):
                t = 1
            elif(-1*value in poc[i]):
                for v in poc[i]:
                    if(v!=(-1*value)):
                        temp_clause.append(v)
            else:
                temp_clause = poc[i]
				
        if(t==0):
            simplified_poc.append(temp_clause)
			
    return simplified_poc,conflict

def max_count(poc,value):
    """returns the number of times a variable is present in the clause """
    count = 0
    for clause in poc:
        for literal in clause:
            if(abs(literal)==value):
                count+=1
    return count

def find_max(poc):
    """Returns that variable which occurs the maximum number of times"""
    count = 0
    max_literal = None
    for clause in poc:
        for literal in clause:
            if(max_count(poc,abs(literal))>count):
                count = max_count(poc,abs(literal))
                max_literal = abs(literal)
            
    return max_literal
""" returns the solution is there is a satisfiable else, returns UNSAT """
def recursion(poc,sol_list):
    
    #base case : If we reach the end of the recursion and we find that poc is empty, which immplies that
    if(poc == []):
        return sol_list,True		

    branch_literal = find_max(poc)
    
    reduced_poc,conflict = BCP(poc,branch_literal)
    
    
    if(not(conflict)):
        sol_list,sat = recursion(reduced_poc,sol_list) # if there is no conflict, then we have to recurse further
        #if there is solution, we get sol_list and sat is equal to true
        if(sat):
                sol_list.append(branch_literal)
                return sol_list,True
        else:
                reduced_poc,conflict = BCP(poc,-1*branch_literal)
                if(not(conflict)):
                        sol_list,sat = recursion(reduced_poc,sol_list)
                        if(sat):
                                sol_list.append(-1*branch_literal)
                                return sol_list,True
                        else:
                                return [],False
                else:
                    return [],False

    else:
        reduced_poc,conflict = BCP(poc,-1*branch_literal)
        if(not(conflict)):
                sol_list,sat = recursion(reduced_poc,sol_list)
                if(sat):
                        sol_list.append(-1*branch_literal)
                        return sol_list,True
                else:
                        return [],False
        else:
                return [],False

def DPLL(poc):
        temp = parse(poc)
        clauses,var_dict = convert(temp)
        sol_list,SAT = recursion(clauses,[])
        if(sol_list != []):
                print(reconvert(sol_list,var_dict),"SAT")
        else:
                print("UNSAT")


if __name__ == "__main__":
    
    test1 = "(!a+!c)(c)(a+b+d)"
    test2 = "(!a + b + c)(d)(e)(f)"

    DPLL(test1)
    DPLL(test2)
        
