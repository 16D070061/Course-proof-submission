M_p = 0.027;
I_p = 0.153;
L_p = 0.191;
r   = 0.08260;
J_m = 3e-05;
M_arm = 0.028;
g = 9.810;
J_eq = 1.23e-04;
J_p = 1.1e-04;
B_eq = 0.0;
B_p = 0.0;
R_m = 3.30;
K_t = 0.02797;
K_m = 0.02797;

A_32  = (r*(M_p^2)*(I_p^2)*g)/(J_p*J_eq + M_p*(I_p^2)*J_eq + J_p*M_p*(r^2));

A_33 = -(K_t*K_m)*(J_p+M_p*(I_p^2))/(R_m*(J_p*J_eq + M_p*(I_p^2)*J_eq + J_p*M_p*(r^2)));

A_42 =  (M_p)*(I_p)*g*(J_eq+M_p*(r^2))/(J_p*J_eq + M_p*(I_p^2)*J_eq + J_p*M_p*(r^2));

A_43 = -(M_p*I_p*K_t*r*K_m)/(R_m*(J_p*J_eq + M_p*(I_p^2)*J_eq + J_p*M_p*(r^2)));

B_3 = (K_t*(J_p + M_p*(I_p^2)))/(R_m*(J_p*J_eq + M_p*(I_p^2)*J_eq + J_p*M_p*(r^2)));

B_4 = (M_p*I_p*K_t*r)/(R_m*(J_p*J_eq + M_p*(I_p^2)*J_eq + J_p*M_p*(r^2)));

A = [0 0 1 0 ; 0 0 0 1; 0 A_32 A_33 0; 0 A_42 A_43 0] ;
B  = [0; 0; B_3;B_4];
C = eye(4);
D = zeros(4,1);

Q = (C')*C;
Q(1,1) = 5;
Q(2,2) = 20;
Q(3,3) = 8;
Q(4,4) = 2;
R = 1

K = lqr(A,B,Q,R)