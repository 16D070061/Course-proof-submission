import random

handle = open('TRACEFILE_multiplier.txt','w')

number_of_testcases = 10000

while number_of_testcases > 0 :
    i = random.randint(0,65535)
    x = '{0:016b}'.format(i)
    handle.write(x)
    j = random.randint(0,65535)
    x = '{0:016b}'.format(j)
    handle.write(x)
    handle.write('\t')        

    y = i*j
    if y > 4294967295:
        y = y - 4294967296
    x = '{0:032b}'.format(y)
    handle.write(x)
    handle.write('\t')
    handle.write('11111111111111111111111111111111')
    handle.write('\n')
    
    number_of_testcases -=1

handle.close()