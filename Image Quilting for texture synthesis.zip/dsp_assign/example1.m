texture = imread('test.jpg');

figure;

imshow(texture);

figure;

outsize = size(texture)*3;
tilesize = 80;
overlapsize = 40;
isdebug = 1;

t2 = synthesize(texture,   outsize , tilesize, overlapsize,isdebug);

imshow(uint8(t2))                       %contrast adjustment